This font is free for PERSONAL USE ONLY!
You will be charged for 100x Standard Desktop License Price 
if you violate this agreement.

Purchase COMMERCIAL & PROMOTIONAL LICENSE:
https://www.arterfakproject.com

Any DONATION will be appreciated
https://www.paypal.me/ahmadramzi

For CUSTOM LICENSE, Please contact us :
arterfakproject@Gmail.com
---------------------------------------
THANK YOU FOR YOUR SUPPORT!